;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="979f5238-5230-bc75-7584-efa3693d6e03")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,964605,e=>{"use strict";var r=e.i(208634),a=e.i(413182);e.i(448088);var t=e.i(756678);e.i(778443);var o=e.i(175233),n=e.i(935268);try{var i=window;i._sentryModuleMetadata=i._sentryModuleMetadata||{},i._sentryModuleMetadata[new i.Error().stack]=Object.assign({},i._sentryModuleMetadata[new i.Error().stack],{"_sentryBundlerPluginAppKey:account":!0})}catch(e){}let s=`
  :root { color-scheme: light dark; --ge-fg: #0a0a0a; --ge-muted: #6b7280; --ge-bg: #ffffff; --ge-border: #d4d4d8; }
  @media (prefers-color-scheme: dark) {
    :root { --ge-fg: #fafafa; --ge-muted: #a1a1aa; --ge-bg: #0a0a0a; --ge-border: #3f3f46; }
  }
  body {
    margin: 0;
    background: var(--ge-bg);
    color: var(--ge-fg);
    font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  }
  main {
    display: flex; flex-direction: column; justify-content: center;
    min-height: 100vh; max-width: 28rem; margin: 0 auto; padding: 2rem 1.5rem;
  }
  h1 { font-size: 1.5rem; font-weight: 600; margin: 0 0 0.5rem; }
  p { color: var(--ge-muted); line-height: 1.5; margin: 0 0 1.5rem; }
  div { display: flex; gap: 0.75rem; flex-wrap: wrap; }
  a, button {
    font: inherit; cursor: pointer; border-radius: 9999px;
    padding: 0.5rem 1.25rem; text-decoration: none; text-align: center;
  }
  a { border: 1px solid var(--ge-border); color: var(--ge-fg); background: transparent; }
  button { border: 1px solid var(--ge-fg); color: var(--ge-bg); background: var(--ge-fg); }
`;e.s(["default",0,function({error:e,reset:i}){let d=(0,t.useLogger)({source:"global-error.tsx"}),g="Invalid URL"==e.message?404:500;return(0,n.useEffect)(()=>{(0,a.captureBoundaryError)(e,"global"),(0,o.parseError)(e)?d.error("Unhandled error: fix this path",{error:e,status:g}):d.error("Unknown error: fix this path",{error:e,status:g})},[e]),(0,r.jsx)("html",{lang:"en",children:(0,r.jsxs)("body",{children:[(0,r.jsx)("style",{children:s}),(0,r.jsxs)("main",{children:[(0,r.jsx)("h1",{children:"An error occurred"}),(0,r.jsx)("p",{children:"There was an error loading this page. Please verify that you are using a correct URL or contact a team admin if the problem persists."}),(0,r.jsxs)("div",{children:[(0,r.jsx)("a",{href:"/",children:"Go to home"}),(0,r.jsx)("button",{type:"button",onClick:i,children:"Retry"})]})]})]})})}])}]);

//# debugId=979f5238-5230-bc75-7584-efa3693d6e03