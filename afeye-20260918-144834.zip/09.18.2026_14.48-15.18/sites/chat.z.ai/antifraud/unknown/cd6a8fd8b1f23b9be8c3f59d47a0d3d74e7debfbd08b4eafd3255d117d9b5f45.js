
			// On page load or when changing themes, best to add inline in `head` to avoid FOUC
			const initTheme = () => {
				const metaThemeColorTag = document.querySelector('meta[name="theme-color"]');
				// 取用户浏览器设置的主题
				// const prefersTheme = window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';

				const prefersTheme = 'light';

				if (!localStorage?.theme) {
					localStorage.theme = prefersTheme;
				}

				if (localStorage.theme === 'system') {
					document.documentElement.classList.add(prefersTheme);
					metaThemeColorTag.setAttribute(
						'content',
						prefersTheme === 'light' ? '#F4F6F8' : '#141618'
					);
				} else if (localStorage.theme === 'light') {
					document.documentElement.classList.add('light');
					metaThemeColorTag.setAttribute('content', '#F4F6F8');
				} else {
					document.documentElement.classList.add('dark');
					metaThemeColorTag.setAttribute('content', '#141618');
				}

				// window.matchMedia('(prefers-color-scheme: dark)').addListener((e) => {
				// 	if (localStorage.theme === 'system') {
				// 		if (e.matches) {
				// 			document.documentElement.classList.add('dark');
				// 			document.documentElement.classList.remove('light');
				// 			metaThemeColorTag.setAttribute('content', '#141618');
				// 		} else {
				// 			document.documentElement.classList.add('light');
				// 			document.documentElement.classList.remove('dark');
				// 			metaThemeColorTag.setAttribute('content', '#F4F6F8');
				// 		}
				// 	}
				// });
			};
			initTheme();
		