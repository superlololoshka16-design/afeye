
			var token = localStorage.getItem('token');
			var base = window.WEBUI_BASE_URL || '';
			var lang = localStorage.locale ?? (navigator.language.includes('zh') ? 'zh-CN' : 'en-US');
			var config = {
				credentials: 'include',
				headers: {
					Accept: 'application/json',
					'Content-Type': 'application/json',
					...(token ? { Authorization: `Bearer ${token}` } : {}),
					'Accept-Language': lang
				}
			};

			var sessionFetch = fetch(`${base}/api/v1/auths/`, config).then(async (res) => {
				if (!res.ok) throw await res.json();
				return res.json();
			});

			window.GLOBAL_FETCHES = {
				session: sessionFetch,
				config: fetch(`${base}/api/config`, config).then(async (res) => {
					if (!res.ok) throw await res.json();
					return res.json();
				}),
				// token 存在时与其他请求并行；不存在时需等 session 之后再请求 models
				// 至少要 cookie 里有 token 才能正常请求 models
				models: token
					? fetch(`${base}/api/models`, config)
					: sessionFetch.then(() => fetch(`${base}/api/models`, config)),
				settings:
					token &&
					fetch(`${base}/api/v1/users/user/settings`, config).then(async (res) => {
						if (!res.ok) throw await res.json();
						return res.json();
					})
			};
		