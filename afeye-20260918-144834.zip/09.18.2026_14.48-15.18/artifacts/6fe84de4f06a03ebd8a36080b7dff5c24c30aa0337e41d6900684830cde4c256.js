(function anonymous(shape,payload,ctx
) {
  const input = payload.value;
  const newResult = {};
  const key_0 = shape["NEXT_PUBLIC_CB_ENVIRONMENT"]._zod.run({ value: input["NEXT_PUBLIC_CB_ENVIRONMENT"], issues: [] }, ctx);
    if (key_0.issues.length) {
      payload.issues = payload.issues.concat(key_0.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_CB_ENVIRONMENT", ...iss.path] : ["NEXT_PUBLIC_CB_ENVIRONMENT"]
      })));
    }
    
    
    if (key_0.value === undefined) {
      if ("NEXT_PUBLIC_CB_ENVIRONMENT" in input) {
        newResult["NEXT_PUBLIC_CB_ENVIRONMENT"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_CB_ENVIRONMENT"] = key_0.value;
    }
    
  
  const key_1 = shape["NEXT_PUBLIC_CODEBUFF_APP_URL"]._zod.run({ value: input["NEXT_PUBLIC_CODEBUFF_APP_URL"], issues: [] }, ctx);
    if (key_1.issues.length) {
      payload.issues = payload.issues.concat(key_1.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_CODEBUFF_APP_URL", ...iss.path] : ["NEXT_PUBLIC_CODEBUFF_APP_URL"]
      })));
    }
    
    
    if (key_1.value === undefined) {
      if ("NEXT_PUBLIC_CODEBUFF_APP_URL" in input) {
        newResult["NEXT_PUBLIC_CODEBUFF_APP_URL"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_CODEBUFF_APP_URL"] = key_1.value;
    }
    
  
  const key_2 = shape["NEXT_PUBLIC_FREEBUFF_APP_URL"]._zod.run({ value: input["NEXT_PUBLIC_FREEBUFF_APP_URL"], issues: [] }, ctx);
    if (key_2.issues.length) {
      payload.issues = payload.issues.concat(key_2.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_FREEBUFF_APP_URL", ...iss.path] : ["NEXT_PUBLIC_FREEBUFF_APP_URL"]
      })));
    }
    
    
    if (key_2.value === undefined) {
      if ("NEXT_PUBLIC_FREEBUFF_APP_URL" in input) {
        newResult["NEXT_PUBLIC_FREEBUFF_APP_URL"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_FREEBUFF_APP_URL"] = key_2.value;
    }
    
  
  const key_3 = shape["NEXT_PUBLIC_SUPPORT_EMAIL"]._zod.run({ value: input["NEXT_PUBLIC_SUPPORT_EMAIL"], issues: [] }, ctx);
    if (key_3.issues.length) {
      payload.issues = payload.issues.concat(key_3.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_SUPPORT_EMAIL", ...iss.path] : ["NEXT_PUBLIC_SUPPORT_EMAIL"]
      })));
    }
    
    
    if (key_3.value === undefined) {
      if ("NEXT_PUBLIC_SUPPORT_EMAIL" in input) {
        newResult["NEXT_PUBLIC_SUPPORT_EMAIL"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_SUPPORT_EMAIL"] = key_3.value;
    }
    
  
  const key_4 = shape["NEXT_PUBLIC_POSTHOG_API_KEY"]._zod.run({ value: input["NEXT_PUBLIC_POSTHOG_API_KEY"], issues: [] }, ctx);
    if (key_4.issues.length) {
      payload.issues = payload.issues.concat(key_4.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_POSTHOG_API_KEY", ...iss.path] : ["NEXT_PUBLIC_POSTHOG_API_KEY"]
      })));
    }
    
    
    if (key_4.value === undefined) {
      if ("NEXT_PUBLIC_POSTHOG_API_KEY" in input) {
        newResult["NEXT_PUBLIC_POSTHOG_API_KEY"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_POSTHOG_API_KEY"] = key_4.value;
    }
    
  
  const key_5 = shape["NEXT_PUBLIC_POSTHOG_HOST_URL"]._zod.run({ value: input["NEXT_PUBLIC_POSTHOG_HOST_URL"], issues: [] }, ctx);
    if (key_5.issues.length) {
      payload.issues = payload.issues.concat(key_5.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_POSTHOG_HOST_URL", ...iss.path] : ["NEXT_PUBLIC_POSTHOG_HOST_URL"]
      })));
    }
    
    
    if (key_5.value === undefined) {
      if ("NEXT_PUBLIC_POSTHOG_HOST_URL" in input) {
        newResult["NEXT_PUBLIC_POSTHOG_HOST_URL"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_POSTHOG_HOST_URL"] = key_5.value;
    }
    
  
  const key_6 = shape["NEXT_PUBLIC_GRAVITY_PIXEL_ID"]._zod.run({ value: input["NEXT_PUBLIC_GRAVITY_PIXEL_ID"], issues: [] }, ctx);
    if (key_6.issues.length) {
      payload.issues = payload.issues.concat(key_6.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_GRAVITY_PIXEL_ID", ...iss.path] : ["NEXT_PUBLIC_GRAVITY_PIXEL_ID"]
      })));
    }
    
    
    if (key_6.value === undefined) {
      if ("NEXT_PUBLIC_GRAVITY_PIXEL_ID" in input) {
        newResult["NEXT_PUBLIC_GRAVITY_PIXEL_ID"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_GRAVITY_PIXEL_ID"] = key_6.value;
    }
    
  
  const key_7 = shape["NEXT_PUBLIC_META_PIXEL_ID"]._zod.run({ value: input["NEXT_PUBLIC_META_PIXEL_ID"], issues: [] }, ctx);
    if (key_7.issues.length) {
      payload.issues = payload.issues.concat(key_7.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_META_PIXEL_ID", ...iss.path] : ["NEXT_PUBLIC_META_PIXEL_ID"]
      })));
    }
    
    
    if (key_7.value === undefined) {
      if ("NEXT_PUBLIC_META_PIXEL_ID" in input) {
        newResult["NEXT_PUBLIC_META_PIXEL_ID"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_META_PIXEL_ID"] = key_7.value;
    }
    
  
  const key_8 = shape["NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY"]._zod.run({ value: input["NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY"], issues: [] }, ctx);
    if (key_8.issues.length) {
      payload.issues = payload.issues.concat(key_8.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY", ...iss.path] : ["NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY"]
      })));
    }
    
    
    if (key_8.value === undefined) {
      if ("NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY" in input) {
        newResult["NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY"] = key_8.value;
    }
    
  
  const key_9 = shape["NEXT_PUBLIC_STRIPE_CUSTOMER_PORTAL"]._zod.run({ value: input["NEXT_PUBLIC_STRIPE_CUSTOMER_PORTAL"], issues: [] }, ctx);
    if (key_9.issues.length) {
      payload.issues = payload.issues.concat(key_9.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_STRIPE_CUSTOMER_PORTAL", ...iss.path] : ["NEXT_PUBLIC_STRIPE_CUSTOMER_PORTAL"]
      })));
    }
    
    
    if (key_9.value === undefined) {
      if ("NEXT_PUBLIC_STRIPE_CUSTOMER_PORTAL" in input) {
        newResult["NEXT_PUBLIC_STRIPE_CUSTOMER_PORTAL"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_STRIPE_CUSTOMER_PORTAL"] = key_9.value;
    }
    
  
  const key_10 = shape["NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION_ID"]._zod.run({ value: input["NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION_ID"], issues: [] }, ctx);
    if (key_10.issues.length) {
      payload.issues = payload.issues.concat(key_10.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION_ID", ...iss.path] : ["NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION_ID"]
      })));
    }
    
    
    if (key_10.value === undefined) {
      if ("NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION_ID" in input) {
        newResult["NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION_ID"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION_ID"] = key_10.value;
    }
    
  
  const key_11 = shape["NEXT_PUBLIC_WEB_PORT"]._zod.run({ value: input["NEXT_PUBLIC_WEB_PORT"], issues: [] }, ctx);
    if (key_11.issues.length) {
      payload.issues = payload.issues.concat(key_11.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_WEB_PORT", ...iss.path] : ["NEXT_PUBLIC_WEB_PORT"]
      })));
    }
    
    
    if (key_11.value === undefined) {
      if ("NEXT_PUBLIC_WEB_PORT" in input) {
        newResult["NEXT_PUBLIC_WEB_PORT"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_WEB_PORT"] = key_11.value;
    }
    
  
  const key_12 = shape["NEXT_PUBLIC_TURNSTILE_SITE_KEY"]._zod.run({ value: input["NEXT_PUBLIC_TURNSTILE_SITE_KEY"], issues: [] }, ctx);
    if (key_12.issues.length) {
      payload.issues = payload.issues.concat(key_12.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_TURNSTILE_SITE_KEY", ...iss.path] : ["NEXT_PUBLIC_TURNSTILE_SITE_KEY"]
      })));
    }
    
    
    if (key_12.value === undefined) {
      if ("NEXT_PUBLIC_TURNSTILE_SITE_KEY" in input) {
        newResult["NEXT_PUBLIC_TURNSTILE_SITE_KEY"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_TURNSTILE_SITE_KEY"] = key_12.value;
    }
    
  
  const key_13 = shape["NEXT_PUBLIC_RECAPTCHA_V2_SITE_KEY"]._zod.run({ value: input["NEXT_PUBLIC_RECAPTCHA_V2_SITE_KEY"], issues: [] }, ctx);
    if (key_13.issues.length) {
      payload.issues = payload.issues.concat(key_13.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_RECAPTCHA_V2_SITE_KEY", ...iss.path] : ["NEXT_PUBLIC_RECAPTCHA_V2_SITE_KEY"]
      })));
    }
    
    
    if (key_13.value === undefined) {
      if ("NEXT_PUBLIC_RECAPTCHA_V2_SITE_KEY" in input) {
        newResult["NEXT_PUBLIC_RECAPTCHA_V2_SITE_KEY"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_RECAPTCHA_V2_SITE_KEY"] = key_13.value;
    }
    
  
  const key_14 = shape["NEXT_PUBLIC_RECAPTCHA_V3_SITE_KEY"]._zod.run({ value: input["NEXT_PUBLIC_RECAPTCHA_V3_SITE_KEY"], issues: [] }, ctx);
    if (key_14.issues.length) {
      payload.issues = payload.issues.concat(key_14.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_RECAPTCHA_V3_SITE_KEY", ...iss.path] : ["NEXT_PUBLIC_RECAPTCHA_V3_SITE_KEY"]
      })));
    }
    
    
    if (key_14.value === undefined) {
      if ("NEXT_PUBLIC_RECAPTCHA_V3_SITE_KEY" in input) {
        newResult["NEXT_PUBLIC_RECAPTCHA_V3_SITE_KEY"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_RECAPTCHA_V3_SITE_KEY"] = key_14.value;
    }
    
  
  const key_15 = shape["NEXT_PUBLIC_RECAPTCHA_V2_SIZE"]._zod.run({ value: input["NEXT_PUBLIC_RECAPTCHA_V2_SIZE"], issues: [] }, ctx);
    if (key_15.issues.length) {
      payload.issues = payload.issues.concat(key_15.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_RECAPTCHA_V2_SIZE", ...iss.path] : ["NEXT_PUBLIC_RECAPTCHA_V2_SIZE"]
      })));
    }
    
    
    if (key_15.value === undefined) {
      if ("NEXT_PUBLIC_RECAPTCHA_V2_SIZE" in input) {
        newResult["NEXT_PUBLIC_RECAPTCHA_V2_SIZE"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_RECAPTCHA_V2_SIZE"] = key_15.value;
    }
    
  
  const key_16 = shape["NEXT_PUBLIC_HUMANBEHAVIOR_API_KEY"]._zod.run({ value: input["NEXT_PUBLIC_HUMANBEHAVIOR_API_KEY"], issues: [] }, ctx);
    if (key_16.issues.length) {
      payload.issues = payload.issues.concat(key_16.issues.map(iss => ({
        ...iss,
        path: iss.path ? ["NEXT_PUBLIC_HUMANBEHAVIOR_API_KEY", ...iss.path] : ["NEXT_PUBLIC_HUMANBEHAVIOR_API_KEY"]
      })));
    }
    
    
    if (key_16.value === undefined) {
      if ("NEXT_PUBLIC_HUMANBEHAVIOR_API_KEY" in input) {
        newResult["NEXT_PUBLIC_HUMANBEHAVIOR_API_KEY"] = undefined;
      }
    } else {
      newResult["NEXT_PUBLIC_HUMANBEHAVIOR_API_KEY"] = key_16.value;
    }
    
  
  payload.value = newResult;
  return payload;
})